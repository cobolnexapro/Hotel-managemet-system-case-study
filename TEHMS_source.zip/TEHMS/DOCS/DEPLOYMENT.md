# TEHMS — Taj Enterprise Hotel Management System
## Runnable Core — Deployment & Operations Guide

This package is a **complete, compilable vertical slice** of TEHMS for IBM i
(AS/400). It runs end to end: **sign-on → main menu → reservation → check-in
(room allocation + folio) → billing (charges, GST, payment) → tax invoice
print → night audit**. Every other module in the master spec (Housekeeping,
Inventory, HR, Finance, etc.) is built by repeating the exact patterns shown
here, so this core doubles as the project's reference implementation.

Target stack: **IBM i 7.3+**, ILE COBOL, DB2 for i (embedded SQL), DDS
display/printer files, ILE CL, IBM Job Scheduler.

---

## 1. Source members in this package

| Source file | Member | Type | Purpose |
|-------------|--------|------|---------|
| QSQLSRC  | TEHMSDDL | SQL  | All tables, indexes, view, triggers, procedure, seed |
| QCPYSRC  | CMXSECDS | CPY  | Session/security descriptor (passed program→program) |
| QCPYSRC  | CMXFKEYS | CPY  | Function-key response indicators |
| QCPYSRC  | CMXERRDS | CPY  | Common error / SQL-status descriptor |
| QCBLLESRC| CMSERROR | CBLLE| Service module: audit / error writer |
| QCBLLESRC| CMSSEC   | CBLLE| Service module: auth, bootstrap, hash, authority |
| QCBLLESRC| CMSBILL  | CBLLE| Service module: invoice recompute (subtotal/GST/total) |
| QSRVSRC  | CMSUTIL  | BND  | Binder source exporting the three service procedures |
| QDDSSRC  | SMDLOGIN | DSPF | Sign-on screen |
| QDDSSRC  | CMDMAIN  | DSPF | Main menu |
| QDDSSRC  | RSDRESV  | DSPF | Reservation maintenance (subfile + detail) |
| QDDSSRC  | BLDBILL  | DSPF | Billing / folio (subfile) |
| QDDSSRC  | BLRINV   | PRTF | GST tax invoice |
| QCBLLESRC| SMILOGIN | CBLLE| Sign-on program |
| QCBLLESRC| CMMMAIN  | CBLLE| Main-menu driver |
| QCBLLESRC| RSIRESV  | CBLLE| Reservation maintenance program |
| QCBLLESRC| BLIBILL  | CBLLE| Billing program |
| QCLSRC   | ADCSETUP | CLLE | One-time environment build |
| QCLSRC   | TEHMSBLD | CLLE | Compile-all orchestration |
| QCLSRC   | ADCNAUDIT| CLLE | Night-audit batch job |

Libraries created: **TEHMSDTA** (data, as an SQL schema so it is
auto-journalled), **TEHMSPGM** (programs/service program/display files/binding
directory), **TEHMSMSG**, **TEHMSSRC** (source).

---

## 2. Upload the source

Create the environment first so the source files exist:

```
CALL ADCSETUP        /* after compiling it, or run the CRTLIB/CRTSRCPF by hand */
```

Then upload each member into the matching source physical file in `TEHMSSRC`
(FTP `quote site`, IBM i Access, RDi, or `CPYFRMSTMF`). Member names must match
the table above. Example with FTP:

```
ftp> quote site namefmt 1
ftp> put SMILOGIN /QSYS.LIB/TEHMSSRC.LIB/QCBLLESRC.FILE/SMILOGIN.MBR
```

(If you prefer, compile `ADCSETUP` itself first:
`CRTBNDCL PGM(TEHMSPGM/ADCSETUP) SRCFILE(TEHMSSRC/QCLSRC) SRCMBR(ADCSETUP)`.)

---

## 3. Build everything

```
CRTBNDCL PGM(TEHMSPGM/TEHMSBLD) SRCFILE(TEHMSSRC/QCLSRC) SRCMBR(TEHMSBLD)
CALL     TEHMSPGM/TEHMSBLD
```

`TEHMSBLD` runs the dependency order automatically:

1. `RUNSQLSTM` TEHMSDDL — tables, indexes, view, triggers, procedure, seed
2. `CRTDSPF` / `CRTPRTF` — display and printer files
3. `CRTSQLCBLI ... OBJTYPE(*MODULE)` — the three service modules
4. `CRTSRVPGM CMSUTIL` — bound from the modules, exports via `EXPORT(*SRCFILE)`
5. `CRTBNDDIR TEHMSBND` + `ADDBNDDIRE` — so callers bind to CMSUTIL statically
6. `CRTBNDCBL` / `CRTSQLCBLI ... OBJTYPE(*PGM) BNDDIR(TEHMSBND)` — the programs

`CALL 'CMSSEC'` etc. resolve **statically** to the service program because the
binding directory is supplied at compile time.

---

## 4. Run it

```
CALL TEHMSPGM/SMILOGIN
```

**Sign-on / first-password bootstrap.** The seed creates three users with
*blank* passwords: `ADMIN` (role ADMIN), `MGR01` (MANAGER), `FRONT01`
(FRONTDESK). On the *first* sign-on for a user, whatever password you type is
hashed, salted and stored as that user's password (`CMSSEC` op `AUTH`). After
that it is validated normally; three consecutive failures lock the user
(`REC_STS = 'I'`).

**Walkthrough**

1. Sign on as `ADMIN`, set a password.
2. From the menu choose **1 = Reservations**. Press **F6** to add: enter a
   guest id (`1000`+ if you seed guests, or insert a guest first — see §6),
   category (`DLX`/`EXEC`/`STE`/`PRES`), dates `DDMMYY`, pax, type, advance.
3. Back on the list, type **C** beside a reservation and press Enter (or F13)
   to **check in** — the system allocates the first vacant room in that
   category, marks it occupied, and opens a folio (invoice header).
4. From the menu choose **4 = Billing**. Enter the **Res #** and press Enter to
   load the folio. **F6** adds charge lines (type/desc/qty/rate/GST%); totals
   recompute via `CMSBILL`. **F10** posts a payment. **F11** prints the GST
   tax invoice (`BLRINV` → spooled file).
5. Run **night audit** to post room nights and roll up open folios:
   ```
   SBMJOB CMD(CALL TEHMSPGM/ADCNAUDIT) JOB(NIGHTAUD)
   ```
   Schedule it with `ADDJOBSCDE JOB(NIGHTAUD) CMD(CALL TEHMSPGM/ADCNAUDIT)
   FRQ(*WEEKLY) SCDDAY(*ALL) SCDTIME(030000)`.

---

## 5. Design notes carried from Phase 1

- **5-layer ILE separation.** Screens never touch DB2 directly except for
  read-only inquiry; all writes/business rules sit in the `CMSxxx` service
  procedures bound through `CMSUTIL`.
- **Naming** `MM + T + mnemonic` (≤10). e.g. `RSPRESV` = Reservation /
  Physical, `RSIRESV` = Reservation / Interactive, `RSDRESV` = Reservation /
  Display.
- **Audit columns** `CRT_TS/CRT_USR/UPD_TS/UPD_USR/REC_STS` on every
  transactional table; `UPD_TS` maintained by BEFORE-UPDATE triggers.
- **Commitment control.** Transactional updates run under `COMMIT(*CHG)` with
  explicit `COMMIT`/`ROLLBACK`; inquiry programs do not commit. Because
  `TEHMSDTA` is an SQL **schema**, all tables are journalled automatically.
- **Money** `DECIMAL(13,2)`, **qty** `DECIMAL(11,3)`, **flags** `CHAR(1)`.
- **GST** modelled per line (`DTL_GSTP`); India CGST/SGST/luxury rates seeded in
  `CMPCONFG` for reporting and rate lookups.

---

## 6. Two things to know before go-live

1. **Password hashing is demo-grade.** `CMSSEC.HASH-PASSWORD` is a deterministic
   salted fold so the package is self-contained and runnable. For production,
   replace that one paragraph with the IBM cryptographic services API
   `Qc3CalculateHash` (SHA-256). The salt column and call sites do not change.
2. **Audit insert shares the caller's commit scope.** A rolled-back transaction
   also rolls back its audit row. For tamper-evident logging, run `CMSERROR`
   in a separate activation group / isolated commit. The seed has no guests;
   add one to exercise reservations:
   ```
   INSERT INTO TEHMSDTA/GMPGUEST (GST_NAME, GST_CITY, GST_PHONE, CRT_USR)
   VALUES ('RATAN MEHTA','MUMBAI','9820012345','ADMIN');
   ```

---

## 7. Extending to the full 12-module system

Each remaining module is a clone of this slice:

- **Housekeeping (HK):** `HKPTASK` table, `HKDTASK` subfile screen, `HKITASK`
  program, status updates to `RMPROOM.RM_CLN` — mirrors RSIRESV.
- **Inventory (IV) / HR / Finance (FN):** master + transaction tables, a subfile
  maintenance program, a service module for the business rule, a printer file
  for the document — mirror the Billing trio (`BLPINVHD/DT`, `BLIBILL`,
  `CMSBILL`, `BLRINV`).
- **Reports (RP):** batch COBOL driven by CL + Job Scheduler, writing externally
  described printer files — mirror `ADCNAUDIT` + `BLRINV`.

Drop new members into the same source files, add their compile lines to
`TEHMSBLD`, and the architecture, security, audit and commitment-control
patterns all carry over unchanged.

---

## 8. Expanded build — modules added

The package now covers eight operational modules off the main menu. Additional
members beyond the original core:

| Source file | Member | Type | Purpose |
|-------------|--------|------|---------|
| QSQLSRC  | TEHMSDDL2 | SQL  | Inventory tables (IVPITEM, IVPTXN) + seed |
| QDDSSRC  | GMDGUEST  | DSPF | Guest profile maintenance |
| QDDSSRC  | RMDROOM   | DSPF | Room & housekeeping |
| QDDSSRC  | GMDCKOUT  | DSPF | Check-out |
| QDDSSRC  | ADDUSER   | DSPF | User administration |
| QDDSSRC  | IVDITEM   | DSPF | Inventory |
| QDDSSRC  | RPROCCUP  | PRTF | Occupancy & revenue report |
| QCBLLESRC| GMIGUEST  | CBLLE| Guest profile maintenance program |
| QCBLLESRC| RMIROOM   | CBLLE| Room & housekeeping program |
| QCBLLESRC| GMICKOUT  | CBLLE| Check-out program |
| QCBLLESRC| ADIUSER   | CBLLE| User administration program |
| QCBLLESRC| IVIITEM   | CBLLE| Inventory program |
| QCBLLESRC| RPBOCCUP  | CBLLE| Occupancy report (batch) |

`TEHMSBLD` already includes every step for these (run `TEHMSDDL2`, create the
new display/printer files, compile the new programs). Just upload the members
and run `CALL TEHMSPGM/TEHMSBLD`.

**Main menu map (CMMMAIN), role-checked via CMSSEC AUTHZ:**

| Opt | Program  | Module | Who |
|-----|----------|--------|-----|
| 1 | RSIRESV  | Reservations / Check-In | FRONTDESK, MANAGER, ADMIN |
| 2 | GMIGUEST | Guest Profiles          | FRONTDESK, MANAGER, ADMIN |
| 3 | GMICKOUT | Check-Out               | FRONTDESK, MANAGER, ADMIN |
| 4 | RMIROOM  | Room & Housekeeping     | FRONTDESK, MANAGER, ADMIN |
| 5 | BLIBILL  | Billing / Invoice       | FRONTDESK, MANAGER, ADMIN |
| 6 | IVIITEM  | Inventory               | MANAGER, ADMIN |
| 7 | RPBOCCUP | Occupancy Report        | MANAGER, ADMIN |
| 8 | ADIUSER  | User Administration     | ADMIN only |
| 90| —        | Sign Off                | all |

**Full life-cycle you can now run:** add a guest (2) → reserve + check in (1,
allocates room + opens folio) → post charges, GST, payment, print (5) →
check out, which settles the folio and frees the room dirty (3) → housekeeping
marks it clean (4) → manager runs occupancy/revenue (7) and stock receive/issue
(6) → admin adds users / resets passwords / locks accounts (8) → night audit
posts room nights and rolls up open folios.

This is a working, multi-module hotel system. The remaining master-spec modules
(HR, full Finance/GL, detailed Reports suite) extend these exact patterns; say
the word and I'll add them in the same style.

---

## 9. HR, Finance/GL and the Reports suite

Three more functional areas complete the enterprise footprint. New members:

| Source file | Member | Type | Purpose |
|-------------|--------|------|---------|
| QSQLSRC  | TEHMSDDL3 | SQL  | HR (dept/employee/payroll) + GL (accounts/journals) + seed |
| QDDSSRC  | HRDEMP    | DSPF | Employee maintenance |
| QDDSSRC  | FNDJRNL   | DSPF | GL journal entry |
| QDDSSRC  | RPDMENU   | DSPF | Reports sub-menu |
| QDDSSRC  | HRRPAY    | PRTF | Payroll register |
| QDDSSRC  | FNRTRIAL  | PRTF | Trial balance |
| QDDSSRC  | RPRREV    | PRTF | Revenue summary |
| QDDSSRC  | RPRSTOCK  | PRTF | Inventory valuation |
| QCBLLESRC| HRIEMP    | CBLLE| Employee maintenance program |
| QCBLLESRC| FNIJRNL   | CBLLE| GL journal entry (must balance to post) |
| QCBLLESRC| HRBPAY    | CBLLE| Payroll run (batch) |
| QCBLLESRC| FNBTRIAL  | CBLLE| Trial balance (batch) |
| QCBLLESRC| RPBREV    | CBLLE| Revenue summary (batch) |
| QCBLLESRC| RPBSTOCK  | CBLLE| Inventory valuation (batch) |
| QCBLLESRC| RPIMENU   | CBLLE| Reports menu driver |

**Updated main menu (CMMMAIN):** 1 Reservations, 2 Guest Profiles, 3 Check-Out,
4 Room & Housekeeping, 5 Billing, 6 Inventory, **7 Human Resources**,
**8 Finance / GL**, **9 Reports**, 10 User Administration, 90 Sign Off.
HR/FN/RP/IV are open to MANAGER and ADMIN; AD is ADMIN only; FRONTDESK keeps
RS/GM/RM/BL (enforced by `CMSSEC` op `AUTHZ`).

**Human Resources (7).** `HRIEMP` maintains the employee master (department,
designation, basic/HRA/deductions). `HRBPAY` (run from the Reports menu or
`SBMJOB CALL HRBPAY`) computes net pay = basic + HRA − deductions for every
active employee, writes `HRPPAY`, and prints the payroll register.

**Finance / General Ledger (8).** `FNIJRNL` captures a double-entry journal: a
draft header is opened, debit/credit lines are added against the seeded chart of
accounts, and the journal **can only be posted when total debits = total
credits**. Posting stamps the header and rolls each line into the account
balance (`ACC_BAL += debit − credit`). An empty unposted draft is removed on
exit. `FNBTRIAL` prints the trial balance — positive balances in the debit
column, negative in credit — with column totals that should agree.

**Reports suite (9).** `RPIMENU` is a sub-menu that runs: 1 Occupancy & Revenue
(`RPBOCCUP`), 2 Revenue Summary (`RPBREV`), 3 Inventory Valuation (`RPBSTOCK`),
4 Trial Balance (`FNBTRIAL`), 5 Payroll Register (`HRBPAY`). Each produces a
spooled file you can view with `WRKSPLF`. All are read-only except payroll,
which records the run in `HRPPAY`.

`TEHMSBLD` already compiles every new object (it runs `TEHMSDDL3`, creates the
new display/printer files, and compiles all the new programs). Upload the
members and run `CALL TEHMSPGM/TEHMSBLD`.

### Coverage now
Twelve functional areas are represented: Security/Sign-on, Reservations,
Guest, Room, Billing, Housekeeping, Inventory, HR, Finance/GL, Reports, plus
Night Audit and Administration. This is a working enterprise core; deepening any
area (e.g. AP/AR sub-ledgers, leave/attendance, rate seasons, F&B POS) repeats
the same table + service + subfile-program + printer pattern already used here.
